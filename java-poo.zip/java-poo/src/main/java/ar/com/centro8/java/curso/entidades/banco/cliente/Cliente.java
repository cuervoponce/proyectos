package ar.com.centro8.java.curso.entidades.banco.cliente;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString 
public abstract class Cliente {
    private int nroCliente;

    public Cliente(int nroCliente){
        this.nroCliente = nroCliente;
    }

}