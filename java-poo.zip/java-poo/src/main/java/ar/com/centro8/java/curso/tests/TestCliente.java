package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.entidades.banco.cliente.ClienteEmpresa;
import ar.com.centro8.java.curso.entidades.banco.cliente.ClienteIndividual;

public class TestCliente {
    public static ClienteIndividual rom= new ClienteIndividual(1, "Leandro", "Romagnoli", "12345678");

    public static ClienteEmpresa emma= new ClienteEmpresa(2, "Emma", "24122014");
    
    public static void main(String[] args) {
        System.out.println(rom.getNombre());
        System.out.println(emma.getNombreFantasia());
    }
    
}