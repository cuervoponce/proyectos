package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.entidades.banco.cuenta.CuentaAhorro;
import static ar.com.centro8.java.curso.tests.TestCliente.rom;

public class TestCuentaAhorro {
    public static CuentaAhorro cuentaRom = new CuentaAhorro(10, rom, "ARS", 0, 15);
    public static void main(String[] args) {
        
        System.out.println("El saldo es: $" + cuentaRom.getSaldo());

        float monto = 8000;
        cuentaRom.depositar(monto);

        System.out.println("Se acreditaron: $" + monto);
        System.out.println("El saldo es: $" + cuentaRom.getSaldo());
        
    }

}