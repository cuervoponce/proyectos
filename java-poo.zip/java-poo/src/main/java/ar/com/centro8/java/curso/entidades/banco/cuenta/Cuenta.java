package ar.com.centro8.java.curso.entidades.banco.cuenta;

import ar.com.centro8.java.curso.entidades.banco.cliente.Cliente;
import lombok.Getter;
import lombok.Setter;

@Setter 
@Getter
public abstract class Cuenta {
    private int nroCuenta;
    private Cliente cliente;
    private String moneda;
    protected float saldo;

    public Cuenta(int nroCuenta, Cliente cliente, String moneda, float saldo) {
        this.nroCuenta = nroCuenta;
        this.cliente = cliente;
        this.moneda = moneda;
        this.saldo = saldo;
    }

    public abstract void depositar(float monto);

    public  abstract void extraer(float monto);



}
