package ar.com.centro8.java.curso.tests;

import static ar.com.centro8.java.curso.tests.TestCliente.emma;
import ar.com.centro8.java.curso.entidades.banco.cuenta.CuentaCorriente;

public class TestCuentaCorriente {
   public static CuentaCorriente cuentaEmma= new CuentaCorriente(7, emma, "ARS", 0, -100000);

   public static void main(String[] args) {

    System.out.println("El saldo es: $" + cuentaEmma.getSaldo());

    float monto = 9000;
    cuentaEmma.depositar(monto);

    
    System.out.println("Se acreditaron: $" + monto);
    System.out.println("El saldo es: $" + cuentaEmma.getSaldo());
   }
   
}