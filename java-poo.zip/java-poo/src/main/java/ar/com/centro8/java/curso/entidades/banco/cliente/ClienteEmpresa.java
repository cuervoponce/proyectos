package ar.com.centro8.java.curso.entidades.banco.cliente;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter 
@Getter
@ToString(callSuper = true)
public class ClienteEmpresa extends Cliente{
    private String nombreFantasia;
    private String cuit;

    public ClienteEmpresa(int nroCliente, String nombreFantasia, String cuit) {
        super(nroCliente);
        this.nombreFantasia = nombreFantasia;
        this.cuit = cuit;
    }

    

}
