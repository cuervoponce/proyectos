package ar.com.centro8.java.curso.tests;

import static ar.com.centro8.java.curso.tests.TestCliente.emma;
import static ar.com.centro8.java.curso.tests.TestCliente.rom;
import static ar.com.centro8.java.curso.tests.TestCuentaAhorro.cuentaRom;
import static ar.com.centro8.java.curso.tests.TestCuentaCorriente.cuentaEmma;
import ar.com.centro8.java.curso.entidades.banco.Banco;

public class TestBanco {
    public static void main(String[] args) {
        Banco banco = new Banco();

        banco.registrarCliente(emma);
        banco.registrarCliente(rom);

        System.out.println(banco.getRegistroCliente());

        banco.registrarCuenta(cuentaRom);
        banco.registrarCuenta(cuentaEmma);

        System.out.println(banco.getRegistroCuenta());

    }
}